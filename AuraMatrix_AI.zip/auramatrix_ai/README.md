# AuraMatrix AI

تطبيق Flutter (واجهة) + خادم Node.js (Backend) يضم:

| الميزة | التنفيذ |
|---|---|
| توليد الفيديو بالذكاء الاصطناعي | واجهة كاملة + وسيط API جاهز. يحتاج مفتاح مزود فيديو (Runway/Luma/Replicate/Fal...) |
| تحسين الصوت | معالجة حقيقية عبر FFmpeg (إزالة ضوضاء، EQ للصوت البشري، تسوية الجهارة) + موجة صوتية متحركة |
| أكاديمية البرمجة والأمن | كورسات ودروس وأكواد من `backend/courses.json` (قابلة للتوسعة) |
| المساعد العلمي | شات عبر Anthropic API، يجيب علمياً وطبياً بما فيه الصحة الجنسية دون تحفظ مصطنع |

## هيكل المشروع

```
auramatrix_ai/
├── logo.svg
├── backend/   (package.json, server.js, courses.json, .env.example)
└── app/       (pubspec.yaml, lib/main.dart, theme.dart, api.dart, logo.dart, screens/*)
```

## تشغيل الخادم

1. ثبّت Node.js 18+ و FFmpeg (`sudo apt install ffmpeg` أو `brew install ffmpeg`).
2. ```
   cd backend
   cp .env.example .env
   ```
3. افتح `.env` وضع `ANTHROPIC_API_KEY` (من console.anthropic.com).
   لتوليد الفيديو ضع `VIDEO_API_URL` و `VIDEO_API_KEY`، ثم عدّل الدالتين `buildVideoPayload` و `parseVideoStatus` في `server.js` لتطابقا صيغة مزودك.
4. ```
   npm install
   npm start
   ```
5. اختبر: `http://localhost:3000/api/health`

## تشغيل التطبيق

1. ثبّت Flutter SDK 3.19+ (`flutter doctor` للتحقق).
2. أنشئ هياكل المنصات داخل مجلد `app`:
   ```
   cd app
   flutter create . --project-name auramatrix_ai
   flutter pub get
   ```
   (الأمر لا يستبدل ملفات `lib/` و `pubspec.yaml` الموجودة، وإن سأل فاحتفظ بملفاتك.)
3. افتح `lib/api.dart` وعدّل `kBaseUrl`:
   - محاكي أندرويد: `http://10.0.2.2:3000`
   - هاتف حقيقي: `http://<IP-جهازك>:3000`
4. أندرويد: أضف في `android/app/src/main/AndroidManifest.xml` داخل `<manifest>` السطرين:
   ```xml
   <uses-permission android:name="android.permission.INTERNET"/>
   ```
   وفي وسم `<application>` أضف `android:usesCleartextTraffic="true"` للتطوير على HTTP.
5. شغّل: `flutter run`
6. للنشر: `flutter build apk --release`

## ملاحظات مهمة

- **الإنتاج:** انشر الخادم على HTTPS (Render/Railway/VPS) وأضف مصادقة للمستخدمين وحداً لعدد الطلبات، فمفتاح API يبقى على الخادم فقط ولا يوضع في التطبيق أبداً.
- **الأمن السيبراني:** المحتوى تعليمي ودفاعي ويركز على المنهجية والمختبرات القانونية (DVWA, Juice Shop, CTF). لا يتضمن أدوات هجومية أو برمجيات خبيثة.
- **المساعد:** يجيب بصراحة علمية في الصحة الجنسية والتشريح والنفس، لكنه لا يكتب محتوى إباحياً ولا يتناول القصّر أو الإكراه.
- **الفيديو:** الواجهة والاتصال جاهزان، لكن التوليد الفعلي يحتاج حساباً مدفوعاً عند مزود فيديو.
