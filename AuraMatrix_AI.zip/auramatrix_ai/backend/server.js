require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const OUTPUT_DIR = path.join(__dirname, 'outputs');
[UPLOAD_DIR, OUTPUT_DIR].forEach((d) => fs.mkdirSync(d, { recursive: true }));
app.use('/files', express.static(OUTPUT_DIR));

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 100 * 1024 * 1024 },
});

// ------------------------------------------------------------------
// 1) Open Scientific AI Assistant  (Anthropic Messages API)
// ------------------------------------------------------------------
const SYSTEM_PROMPT = `You are AuraMatrix Scientific Assistant, an objective, neutral and
knowledgeable assistant for science, technology, health and education.
Reply in the same language as the user (Arabic or English).

You answer questions on sexual and reproductive health, anatomy, physiology,
psychology and sex education directly, factually and without embarrassment,
moralizing or needless disclaimers, the way a good doctor, nurse or sex educator
would. Use correct medical terminology and clear explanations.

Boundaries you always keep:
- No sexual content involving minors, and no sexualization of anyone under 18.
- No sexually explicit erotica or pornographic storytelling: you inform and
  educate, you do not write arousal-oriented material.
- No content that promotes coercion, non-consent, abuse or harm to others.
- For symptoms, pain, medication or infections, give general information and
  suggest seeing a doctor when appropriate.
- Cybersecurity: explain concepts, defense and legal lab practice. Do not write
  working malware or exploits, and do not help attack systems the user does not own.`;

app.post('/api/chat', async (req, res) => {
  try {
    const { messages } = req.body; // [{role:'user'|'assistant', content:'...'}]
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'messages is required' });
    }
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY || '',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
        max_tokens: 1500,
        system: SYSTEM_PROMPT,
        messages: messages.slice(-20),
      }),
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: data?.error?.message || 'API error' });
    const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n');
    res.json({ reply: text });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ------------------------------------------------------------------
// 2) AI Video Generation  (provider-agnostic proxy)
//    Set VIDEO_API_URL / VIDEO_API_KEY in .env for your provider
//    (Runway, Luma, Replicate, Fal, ...). Adjust buildVideoPayload()
//    and parseVideoStatus() to match the provider's JSON format.
// ------------------------------------------------------------------
function buildVideoPayload({ prompt, resolution, speed, duration }) {
  return { prompt, resolution, speed, duration };
}
function parseVideoStatus(data) {
  // Map the provider response to { status: 'processing'|'done'|'failed', url? }
  return { status: data.status || 'processing', url: data.url || data.output || null };
}

app.post('/api/video/generate', async (req, res) => {
  const { prompt, resolution = '1080p', speed = 1.0, duration = 5 } = req.body;
  if (!prompt) return res.status(400).json({ error: 'prompt is required' });
  if (!process.env.VIDEO_API_URL || !process.env.VIDEO_API_KEY) {
    return res.status(501).json({
      error: 'Video provider is not configured. Set VIDEO_API_URL and VIDEO_API_KEY in backend/.env',
    });
  }
  try {
    const r = await fetch(process.env.VIDEO_API_URL, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        authorization: `Bearer ${process.env.VIDEO_API_KEY}`,
      },
      body: JSON.stringify(buildVideoPayload({ prompt, resolution, speed, duration })),
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({ error: data?.error || 'Provider error' });
    res.json({ jobId: data.id || data.job_id, ...parseVideoStatus(data) });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/video/status/:id', async (req, res) => {
  if (!process.env.VIDEO_API_URL || !process.env.VIDEO_API_KEY) {
    return res.status(501).json({ error: 'Video provider is not configured' });
  }
  try {
    const r = await fetch(`${process.env.VIDEO_API_URL}/${encodeURIComponent(req.params.id)}`, {
      headers: { authorization: `Bearer ${process.env.VIDEO_API_KEY}` },
    });
    const data = await r.json();
    res.status(r.ok ? 200 : r.status).json(parseVideoStatus(data));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ------------------------------------------------------------------
// 3) Audio Enhancement  (real processing with FFmpeg)
//    Requires ffmpeg installed on the server.
//    highpass -> afftdn (spectral noise reduction) -> speech EQ -> loudnorm
// ------------------------------------------------------------------
app.post('/api/audio/enhance', upload.single('audio'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'audio file is required' });
  const strength = Math.min(40, Math.max(5, parseInt(req.body.strength || '20', 10)));
  const id = crypto.randomBytes(6).toString('hex');
  const outName = `enhanced_${id}.mp3`;
  const outPath = path.join(OUTPUT_DIR, outName);

  const filters = [
    'highpass=f=70',
    `afftdn=nr=${strength}:nf=-30`,
    'equalizer=f=3000:t=q:w=1:g=2',
    'loudnorm=I=-16:TP=-1.5:LRA=11',
  ].join(',');

  const ff = spawn('ffmpeg', ['-y', '-i', req.file.path, '-af', filters, '-b:a', '192k', outPath]);
  let err = '';
  ff.stderr.on('data', (d) => (err += d.toString()));
  ff.on('error', () => {
    fs.unlink(req.file.path, () => {});
    res.status(500).json({ error: 'ffmpeg is not installed on the server' });
  });
  ff.on('close', (code) => {
    fs.unlink(req.file.path, () => {});
    if (code !== 0) return res.status(500).json({ error: 'processing failed', detail: err.slice(-400) });
    res.json({ url: `${req.protocol}://${req.get('host')}/files/${outName}` });
  });
});

// ------------------------------------------------------------------
// 4) Academy content
// ------------------------------------------------------------------
app.get('/api/academy', (req, res) => {
  const file = path.join(__dirname, 'courses.json');
  res.json(JSON.parse(fs.readFileSync(file, 'utf8')));
});

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`AuraMatrix backend running on http://localhost:${PORT}`));
