import 'package:flutter/material.dart';
import 'theme.dart';
import 'logo.dart';
import 'screens/video_screen.dart';
import 'screens/audio_screen.dart';
import 'screens/academy_screen.dart';
import 'screens/assistant_screen.dart';

void main() => runApp(const AuraMatrixApp());

class AuraMatrixApp extends StatelessWidget {
  const AuraMatrixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AuraMatrix AI',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _index = 0;
  final _pages = const [
    VideoScreen(),
    AudioScreen(),
    AcademyScreen(),
    AssistantScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const AuraTitle()),
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.movie_creation_outlined), label: 'فيديو'),
          NavigationDestination(
              icon: Icon(Icons.graphic_eq), label: 'الصوت'),
          NavigationDestination(
              icon: Icon(Icons.school_outlined), label: 'الأكاديمية'),
          NavigationDestination(
              icon: Icon(Icons.psychology_outlined), label: 'المساعد'),
        ],
      ),
    );
  }
}
