import 'dart:async';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../api.dart';
import '../theme.dart';

class VideoScreen extends StatefulWidget {
  const VideoScreen({super.key});
  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  final _prompt = TextEditingController();
  String _resolution = '1080p';
  double _speed = 1.0;
  double _duration = 5;
  bool _busy = false;
  String? _status;
  String? _error;
  VideoPlayerController? _player;
  Timer? _poll;

  @override
  void dispose() {
    _poll?.cancel();
    _player?.dispose();
    _prompt.dispose();
    super.dispose();
  }

  Future<void> _generate() async {
    if (_prompt.text.trim().isEmpty) return;
    setState(() {
      _busy = true;
      _error = null;
      _status = 'جاري إرسال الطلب...';
    });
    try {
      final res = await Api.generateVideo(
        prompt: _prompt.text.trim(),
        resolution: _resolution,
        speed: _speed,
        duration: _duration.round(),
      );
      if (res['url'] != null && res['status'] == 'done') {
        await _show(res['url']);
      } else {
        _startPolling(res['jobId'].toString());
      }
    } catch (e) {
      setState(() {
        _busy = false;
        _status = null;
        _error = e.toString();
      });
    }
  }

  void _startPolling(String id) {
    _poll?.cancel();
    setState(() => _status = 'جاري توليد الفيديو... قد يستغرق دقائق');
    _poll = Timer.periodic(const Duration(seconds: 5), (t) async {
      try {
        final s = await Api.videoStatus(id);
        if (s['status'] == 'done' && s['url'] != null) {
          t.cancel();
          await _show(s['url']);
        } else if (s['status'] == 'failed') {
          t.cancel();
          setState(() {
            _busy = false;
            _status = null;
            _error = 'فشل توليد الفيديو';
          });
        }
      } catch (e) {
        t.cancel();
        setState(() {
          _busy = false;
          _status = null;
          _error = e.toString();
        });
      }
    });
  }

  Future<void> _show(String url) async {
    _player?.dispose();
    final c = VideoPlayerController.networkUrl(Uri.parse(url));
    await c.initialize();
    c.setLooping(true);
    c.play();
    if (!mounted) return;
    setState(() {
      _player = c;
      _busy = false;
      _status = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('حوّل النص إلى فيديو',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        const Text('اكتب وصفاً دقيقاً للمشهد والحركة والإضاءة.',
            style: TextStyle(color: AppColors.muted)),
        const SizedBox(height: 16),
        TextField(
          controller: _prompt,
          minLines: 4,
          maxLines: 6,
          decoration: const InputDecoration(
              hintText: 'مثال: مدينة مستقبلية ليلاً بأضواء نيون زرقاء، لقطة سينمائية بطيئة...'),
        ),
        const SizedBox(height: 16),
        const Text('الدقة'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: ['480p', '720p', '1080p', '4K']
              .map((r) => ChoiceChip(
                    label: Text(r),
                    selected: _resolution == r,
                    onSelected: (_) => setState(() => _resolution = r),
                  ))
              .toList(),
        ),
        const SizedBox(height: 12),
        Text('السرعة: ${_speed.toStringAsFixed(1)}x'),
        Slider(
          value: _speed,
          min: 0.5,
          max: 2.0,
          divisions: 6,
          onChanged: (v) => setState(() => _speed = v),
        ),
        Text('المدة: ${_duration.round()} ثوانٍ'),
        Slider(
          value: _duration,
          min: 3,
          max: 15,
          divisions: 12,
          onChanged: (v) => setState(() => _duration = v),
        ),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: _busy ? null : _generate,
          icon: const Icon(Icons.auto_awesome),
          label: const Text('توليد الفيديو'),
        ),
        if (_status != null) ...[
          const SizedBox(height: 16),
          const LinearProgressIndicator(),
          const SizedBox(height: 8),
          Text(_status!, style: const TextStyle(color: AppColors.muted)),
        ],
        if (_error != null) ...[
          const SizedBox(height: 16),
          Text(_error!, style: const TextStyle(color: Colors.redAccent)),
        ],
        if (_player != null) ...[
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: AspectRatio(
              aspectRatio: _player!.value.aspectRatio,
              child: VideoPlayer(_player!),
            ),
          ),
        ],
      ],
    );
  }
}
