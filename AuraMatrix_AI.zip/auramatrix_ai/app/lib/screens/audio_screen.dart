import 'dart:io';
import 'dart:math';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../api.dart';
import '../theme.dart';

class AudioScreen extends StatefulWidget {
  const AudioScreen({super.key});
  @override
  State<AudioScreen> createState() => _AudioScreenState();
}

class _AudioScreenState extends State<AudioScreen>
    with SingleTickerProviderStateMixin {
  File? _file;
  String? _name;
  double _strength = 20;
  bool _busy = false;
  String? _resultUrl;
  String? _error;
  final _player = AudioPlayer();
  bool _playing = false;
  late final AnimationController _anim;
  final _rand = Random(7);
  late List<double> _bars;

  @override
  void initState() {
    super.initState();
    _bars = List.generate(48, (_) => 0.15 + _rand.nextDouble() * 0.85);
    _anim = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1400))
      ..repeat();
    _player.onPlayerComplete.listen((_) => setState(() => _playing = false));
  }

  @override
  void dispose() {
    _anim.dispose();
    _player.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (r == null || r.files.single.path == null) return;
    setState(() {
      _file = File(r.files.single.path!);
      _name = r.files.single.name;
      _resultUrl = null;
      _error = null;
      _bars = List.generate(48, (_) => 0.15 + _rand.nextDouble() * 0.85);
    });
  }

  Future<void> _enhance() async {
    if (_file == null) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final url = await Api.enhanceAudio(_file!, _strength.round());
      setState(() => _resultUrl = url);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _togglePlay() async {
    if (_resultUrl == null) return;
    if (_playing) {
      await _player.pause();
      setState(() => _playing = false);
    } else {
      await _player.play(UrlSource(_resultUrl!));
      setState(() => _playing = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('تحسين وهندسة الصوت',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        const Text('تنقية الضوضاء، ضبط الصوت البشري، وتسوية مستوى الجهارة.',
            style: TextStyle(color: AppColors.muted)),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                SizedBox(
                  height: 90,
                  child: AnimatedBuilder(
                    animation: _anim,
                    builder: (_, __) => CustomPaint(
                      size: const Size(double.infinity, 90),
                      painter: _WavePainter(
                        bars: _bars,
                        phase: _anim.value,
                        active: _busy || _playing,
                        done: _resultUrl != null,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(_name ?? 'لم يتم اختيار ملف',
                    style: const TextStyle(color: AppColors.muted)),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _busy ? null : _pick,
                  icon: const Icon(Icons.upload_file),
                  label: const Text('رفع ملف صوتي'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text('قوة إزالة الضوضاء: ${_strength.round()} dB'),
        Slider(
          value: _strength,
          min: 5,
          max: 40,
          divisions: 35,
          onChanged: (v) => setState(() => _strength = v),
        ),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: (_file == null || _busy) ? null : _enhance,
          icon: const Icon(Icons.auto_fix_high),
          label: const Text('تحسين الصوت'),
        ),
        if (_busy) ...[
          const SizedBox(height: 16),
          const LinearProgressIndicator(),
          const SizedBox(height: 8),
          const Text('جاري المعالجة...',
              style: TextStyle(color: AppColors.muted)),
        ],
        if (_error != null) ...[
          const SizedBox(height: 16),
          Text(_error!, style: const TextStyle(color: Colors.redAccent)),
        ],
        if (_resultUrl != null) ...[
          const SizedBox(height: 16),
          Card(
            child: ListTile(
              leading: IconButton(
                icon: Icon(_playing ? Icons.pause_circle : Icons.play_circle,
                    size: 38, color: AppColors.neonSoft),
                onPressed: _togglePlay,
              ),
              title: const Text('الصوت بعد التحسين'),
              subtitle: const Text('اضغط للاستماع'),
            ),
          ),
        ],
      ],
    );
  }
}

class _WavePainter extends CustomPainter {
  final List<double> bars;
  final double phase;
  final bool active;
  final bool done;
  _WavePainter({
    required this.bars,
    required this.phase,
    required this.active,
    required this.done,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width / bars.length;
    final paint = Paint()
      ..strokeCap = StrokeCap.round
      ..strokeWidth = w * 0.55
      ..color = done ? AppColors.neonSoft : AppColors.neon.withOpacity(0.6);
    for (int i = 0; i < bars.length; i++) {
      var h = bars[i];
      if (active) {
        h *= 0.55 + 0.45 * sin((phase * 2 * pi) + i * 0.5).abs();
      } else if (done) {
        h = h * 0.8 + 0.1;
      }
      final x = i * w + w / 2;
      final half = h * size.height / 2;
      canvas.drawLine(Offset(x, size.height / 2 - half),
          Offset(x, size.height / 2 + half), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _WavePainter old) => true;
}
