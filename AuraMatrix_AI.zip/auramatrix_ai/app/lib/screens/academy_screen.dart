import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../api.dart';
import '../theme.dart';

class AcademyScreen extends StatefulWidget {
  const AcademyScreen({super.key});
  @override
  State<AcademyScreen> createState() => _AcademyScreenState();
}

class _AcademyScreenState extends State<AcademyScreen> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = Api.academy();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('تعذر الاتصال بالخادم\n${snap.error}',
                      textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: () => setState(() => _future = Api.academy()),
                    child: const Text('إعادة المحاولة'),
                  ),
                ],
              ),
            ),
          );
        }
        final courses = (snap.data!['courses'] as List).cast<Map>();
        final articles = (snap.data!['articles'] as List).cast<Map>();
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('أكاديمية البرمجة والأمن السيبراني',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            const Text('تعلّم بالتطبيق العملي ضمن إطار قانوني وأخلاقي.',
                style: TextStyle(color: AppColors.muted)),
            const SizedBox(height: 16),
            const Text('الكورسات',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            ...courses.map((c) => Card(
                  child: ListTile(
                    title: Text(c['title']),
                    subtitle: Text(
                        '${c['level']} • ${(c['lessons'] as List).length} دروس'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => CourseScreen(course: c)),
                    ),
                  ),
                )),
            const SizedBox(height: 16),
            const Text('مقالات',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            ...articles.map((a) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.article_outlined),
                    title: Text(a['title']),
                    subtitle: Text(a['summary']),
                  ),
                )),
          ],
        );
      },
    );
  }
}

class CourseScreen extends StatelessWidget {
  final Map course;
  const CourseScreen({super.key, required this.course});

  @override
  Widget build(BuildContext context) {
    final lessons = (course['lessons'] as List).cast<Map>();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(course['title'])),
        body: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: lessons.length,
          itemBuilder: (_, i) {
            final l = lessons[i];
            return Card(
              margin: const EdgeInsets.only(bottom: 14),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${i + 1}. ${l['title']}',
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    Text(l['body'], style: const TextStyle(height: 1.6)),
                    if (l['code'] != null) ...[
                      const SizedBox(height: 12),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFF07090B),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Directionality(
                          textDirection: TextDirection.ltr,
                          child: SelectableText(
                            l['code'],
                            style: const TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 12.5,
                                color: AppColors.neonSoft),
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: TextButton.icon(
                          onPressed: () =>
                              Clipboard.setData(ClipboardData(text: l['code'])),
                          icon: const Icon(Icons.copy, size: 16),
                          label: const Text('نسخ الكود'),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
