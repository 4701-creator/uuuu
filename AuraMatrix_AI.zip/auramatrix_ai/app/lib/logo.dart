import 'dart:math';
import 'package:flutter/material.dart';
import 'theme.dart';

/// AuraMatrix logo: interconnected neural-network nodes in neon blue
/// on a charcoal rounded square. Drawn with CustomPainter (no assets).
class LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width;
    final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, s, s), Radius.circular(s * 0.24));
    canvas.drawRRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A1F26), Color(0xFF07090B)],
        ).createShader(Rect.fromLTWH(0, 0, s, s)),
    );
    canvas.drawRRect(
      rect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = s * 0.012
        ..color = AppColors.neon.withOpacity(0.5),
    );

    final c = Offset(s / 2, s / 2);
    final r = s * 0.30;
    final nodes = <Offset>[
      for (int i = 0; i < 6; i++)
        c + Offset(cos(i * pi / 3 - pi / 2), sin(i * pi / 3 - pi / 2)) * r,
    ];

    final glow = Paint()
      ..color = AppColors.neon.withOpacity(0.35)
      ..strokeWidth = s * 0.03
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, s * 0.03);
    final line = Paint()
      ..color = AppColors.neonSoft
      ..strokeWidth = s * 0.012
      ..strokeCap = StrokeCap.round;

    for (int i = 0; i < nodes.length; i++) {
      for (int j = i + 1; j < nodes.length; j++) {
        canvas.drawLine(nodes[i], nodes[j], glow);
        canvas.drawLine(nodes[i], nodes[j], line);
      }
      canvas.drawLine(nodes[i], c, line);
    }
    for (final n in nodes) {
      canvas.drawCircle(n, s * 0.045, Paint()..color = AppColors.neon);
      canvas.drawCircle(n, s * 0.02, Paint()..color = Colors.white);
    }
    canvas.drawCircle(c, s * 0.07, Paint()..color = AppColors.neon);
    canvas.drawCircle(c, s * 0.03, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class AuraLogo extends StatelessWidget {
  final double size;
  const AuraLogo({super.key, this.size = 48});

  @override
  Widget build(BuildContext context) =>
      CustomPaint(size: Size.square(size), painter: LogoPainter());
}

class AuraTitle extends StatelessWidget {
  const AuraTitle({super.key});
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: const [
        AuraLogo(size: 30),
        SizedBox(width: 10),
        Text('AuraMatrix',
            style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 0.5)),
        Text(' AI',
            style: TextStyle(
                fontWeight: FontWeight.w800, color: AppColors.neonSoft)),
      ],
    );
  }
}
