import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

/// Change this to your server address.
/// Android emulator -> http://10.0.2.2:3000
/// iOS simulator / desktop -> http://localhost:3000
/// Real phone -> http://<your-computer-LAN-IP>:3000 (or your deployed URL)
const String kBaseUrl = 'http://10.0.2.2:3000';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class Api {
  static Map<String, dynamic> _decode(http.Response r) {
    final body = r.body.isEmpty ? '{}' : r.body;
    final data = jsonDecode(body) as Map<String, dynamic>;
    if (r.statusCode >= 400) {
      throw ApiException(data['error']?.toString() ?? 'خطأ ${r.statusCode}');
    }
    return data;
  }

  static Future<String> chat(List<Map<String, String>> messages) async {
    final r = await http
        .post(
          Uri.parse('$kBaseUrl/api/chat'),
          headers: {'content-type': 'application/json'},
          body: jsonEncode({'messages': messages}),
        )
        .timeout(const Duration(seconds: 90));
    return _decode(r)['reply'] as String;
  }

  static Future<Map<String, dynamic>> generateVideo({
    required String prompt,
    required String resolution,
    required double speed,
    required int duration,
  }) async {
    final r = await http.post(
      Uri.parse('$kBaseUrl/api/video/generate'),
      headers: {'content-type': 'application/json'},
      body: jsonEncode({
        'prompt': prompt,
        'resolution': resolution,
        'speed': speed,
        'duration': duration,
      }),
    );
    return _decode(r);
  }

  static Future<Map<String, dynamic>> videoStatus(String id) async {
    final r = await http.get(Uri.parse('$kBaseUrl/api/video/status/$id'));
    return _decode(r);
  }

  static Future<String> enhanceAudio(File file, int strength) async {
    final req = http.MultipartRequest(
        'POST', Uri.parse('$kBaseUrl/api/audio/enhance'))
      ..fields['strength'] = strength.toString()
      ..files.add(await http.MultipartFile.fromPath('audio', file.path));
    final streamed = await req.send().timeout(const Duration(minutes: 5));
    final r = await http.Response.fromStream(streamed);
    return _decode(r)['url'] as String;
  }

  static Future<Map<String, dynamic>> academy() async {
    final r = await http.get(Uri.parse('$kBaseUrl/api/academy'));
    return _decode(r);
  }
}
